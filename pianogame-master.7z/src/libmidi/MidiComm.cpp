
// Copyright (c)2007 Nicholas Piegdon
// See license.txt for license information

#include "MidiEvent.h"
#include "MidiComm.h"
#include "MidiUtil.h"

#include <string>
#include <sstream>
using namespace std;

#include "../os.h"
#include "../UserSettings.h"
#include "../CompatibleSystem.h"
#include "../string_util.h"

void midi_check(MMRESULT ret)
{
   if (ret == MMSYSERR_NOERROR) return;

   switch (ret)
   {
   case MIDIERR_NODEVICE:     throw MidiError(MidiError_MM_NoDevice);
   case MMSYSERR_NOTENABLED:  throw MidiError(MidiError_MM_NotEnabled);
   case MMSYSERR_ALLOCATED:   throw MidiError(MidiError_MM_AlreadyAllocated);
   case MMSYSERR_BADDEVICEID: throw MidiError(MidiError_MM_BadDeviceID);
   case MMSYSERR_INVALPARAM:  throw MidiError(MidiError_MM_InvalidParameter);
   case MMSYSERR_NODRIVER:    throw MidiError(MidiError_MM_NoDriver);
   case MMSYSERR_NOMEM:       throw MidiError(MidiError_MM_NoMemory);
   default:                   throw MidiError(MidiError_MM_Unknown);
   }
}

void CALLBACK MidiInputCallback(HMIDIIN, UINT msg, DWORD_PTR instance, DWORD p1, DWORD p2)
{
   reinterpret_cast<MidiCommIn*>(instance)->InputCallback(msg, p1, p2);
}

MidiCommDescriptionList MidiCommIn::GetDeviceList()
{
   MidiCommDescriptionList devices;

   unsigned int dev_count = midiInGetNumDevs();
   for (unsigned int i = 0; i < dev_count; ++i)
   {
      MIDIINCAPS dev;

      const static int MaxTries = 10;
      int tries = 0;
      while (tries++ < MaxTries)
      {
         try
         {
            midi_check(midiInGetDevCaps(i, &dev, sizeof(MIDIINCAPS)));
            break;
         }
         catch (MidiError ex)
         {
            // Sometimes input needs to take a quick break
            if (ex.m_error != MidiError_MM_NotEnabled) throw;
            Sleep(50);
         }
      }
      if (tries == MaxTries) throw MidiError_MM_NotEnabled;

      MidiCommDescription d;
      d.id = i;
      d.name = dev.szPname;

      devices.push_back(d);
   }

   return devices;
}

MidiCommIn::MidiCommIn(unsigned int device_id)
{
   m_description = GetDeviceList()[device_id];

   InitializeCriticalSection(&m_buffer_mutex);

   midi_check(midiInOpen(&m_input_device, device_id,
      reinterpret_cast<DWORD_PTR>(MidiInputCallback),
      reinterpret_cast<DWORD_PTR>(this),
      CALLBACK_FUNCTION));
   
   midi_check(midiInStart(m_input_device));
}

MidiCommIn::~MidiCommIn()
{
   midi_check(midiInStop(m_input_device));
   midi_check(midiInReset(m_input_device));
   midi_check(midiInClose(m_input_device));

   DeleteCriticalSection(&m_buffer_mutex);
}

// This is only called by the callback function.  The reason this
// is public (and the callback isn't a static member) is to keep the
// HMIDIIN definition out of this classes header.
void MidiCommIn::InputCallback(unsigned int msg, unsigned long p1, unsigned long)
{
   try
   {
      switch (msg)
      {
      case MIM_DATA:
         {
            unsigned char status = LOBYTE(LOWORD(p1));
            unsigned char byte1  = HIBYTE(LOWORD(p1));
            unsigned char byte2  = LOBYTE(HIWORD(p1));
            MidiEvent ev = MidiEvent::Build(MidiEventSimple(status, byte1, byte2));

            EnterCriticalSection(&m_buffer_mutex);
            m_event_buffer.push(ev);
            LeaveCriticalSection(&m_buffer_mutex);
         }
         break;

      case MIM_OPEN:
      case MIM_CLOSE:
         // Ignore
         break;

      case MIM_LONGDATA:
      case MIM_LONGERROR:
         // Ignore SysEx and SysEx errors
         break;

      case MIM_MOREDATA:
         // This should never be called, and is
         // non-fatal if it is.
         break;

      case MIM_ERROR:
         {
            // LOGTODO: This is a VERY good candidate to log someday.

            // Find out how we're supposed to treat this error
            const std::wstring behavior = UserSetting::Get(L"InputError", L"report");
            if (behavior == L"report") throw MidiError(MidiError_InputError);
            if (behavior == L"ignore") break;
            if (behavior == L"use")
            {
               unsigned char status = LOBYTE(LOWORD(p1));
               unsigned char byte1  = HIBYTE(LOWORD(p1));
               unsigned char byte2  = LOBYTE(HIWORD(p1));
               MidiEvent ev = MidiEvent::Build(MidiEventSimple(status, byte1, byte2));

               EnterCriticalSection(&m_buffer_mutex);
               m_event_buffer.push(ev);
               LeaveCriticalSection(&m_buffer_mutex);
               break;
            }
            throw MidiError(MidiError_InvalidInputErrorBehavior);
         }
         break;
      }
   }
   catch (const MidiError &e)
   {
      // TODO: These appear in main.cpp too.  Consolidate them.
      const static wstring error_header1 = L"SFBM detected a";
      const static wstring error_header2 = L" problem and must close:\n\n";
      const static wstring error_footer = L"\n";

      wstring wrapped_description = WSTRING(error_header1 << L" MIDI" << error_header2 << e.GetErrorDescription() << error_footer);
      Compatible::ShowError(wrapped_description);

      // Not much else we can do!
      exit(1);
   }

}

void MidiCommIn::Reset()
{
   EnterCriticalSection(&m_buffer_mutex);
   while (!m_event_buffer.empty()) m_event_buffer.pop();
   LeaveCriticalSection(&m_buffer_mutex);
}

bool MidiCommIn::KeepReading() const
{
   bool buffer_empty;

   EnterCriticalSection(&m_buffer_mutex);
   buffer_empty = m_event_buffer.empty();
   LeaveCriticalSection(&m_buffer_mutex);

   return (!buffer_empty);
}

MidiEvent MidiCommIn::Read()
{
   MidiEvent ev(MidiEvent::NullEvent());
   bool buffer_empty;

   EnterCriticalSection(&m_buffer_mutex);
   buffer_empty = m_event_buffer.empty();
   if (!buffer_empty)
   {
      ev = m_event_buffer.front();
      m_event_buffer.pop();
   }
   LeaveCriticalSection(&m_buffer_mutex);

   if (buffer_empty) throw MidiError(MidiError_NoInputAvailable);
   return ev;
}

MidiCommDescriptionList MidiCommOut::GetDeviceList()
{
   MidiCommDescriptionList devices;

   unsigned int dev_count = midiOutGetNumDevs();
   for (unsigned int i = 0; i < dev_count; ++i)
   {
      MIDIOUTCAPS dev;
      midi_check(midiOutGetDevCaps(i, &dev, sizeof(MIDIOUTCAPS)));

      MidiCommDescription d;
      d.id = i;
      d.name = dev.szPname;

      devices.push_back(d);
   }

   return devices;
}

MidiCommOut::MidiCommOut(unsigned int device_id)
{
   m_description = GetDeviceList()[device_id];

   midi_check(midiOutOpen(&m_output_device, device_id, 0, 0, CALLBACK_NULL));
}

MidiCommOut::~MidiCommOut()
{
   midi_check(midiOutReset(m_output_device));
   midi_check(midiOutClose(m_output_device));
}

void MidiCommOut::Write(const MidiEvent &out)
{
   MidiEventSimple simple;
   if (out.GetSimpleEvent(&simple))
   {
      // You could use a bunch of MAKELONG(MAKEWORD(lo,hi), MAKEWORD(lo,hi)) stuff here, but
      // this is easier to read and likely faster.
      unsigned long message = simple.status | (simple.byte1 << 8) | (simple.byte2 << 16);

      midi_check(midiOutShortMsg(m_output_device, message));
   }
}

void MidiCommOut::Reset()
{
   midi_check(midiOutReset(m_output_device));
   // this is probably completely unnecessary
   //midi_check(midiOutClose(m_output_device));
   //midi_check(midiOutOpen(&m_output_device, m_description.id, 0, 0, CALLBACK_NULL));
}