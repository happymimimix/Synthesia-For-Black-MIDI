
// Copyright (c)2007 Nicholas Piegdon
// See license.txt for license information

#ifndef __MIDI_TYPES_H
#define __MIDI_TYPES_H

typedef long long microseconds_t;

#endif
