
// Copyright (c)2007 Nicholas Piegdon
// See license.txt for license information

#ifndef __PIANOGAME_VERSION_H
#define __PIANOGAME_VERSION_H

#include <string>

// See readme.txt for a list of what has changed between versions
static const std::wstring PianoGameVersionString = L"v1.4.2";

#endif
