
// Copyright (c)2007 Nicholas Piegdon
// See license.txt for license information

#include "CompatibleSystem.h"
#include "string_util.h"
#include "version.h"
#include "os.h"


namespace Compatible
{
   unsigned long GetMilliseconds()
   {
      return timeGetTime();
   }


   void ShowError(const std::wstring &err)
   {
      const static std::wstring friendly_app_name = WSTRING(L"SFBM " + PianoGameVersionString);
      const static std::wstring message_box_title = WSTRING(friendly_app_name << L" Error");
      
      MessageBox(0, err.c_str(), message_box_title.c_str(), MB_ICONERROR);
   }
   
   void ShowMouseCursor()
   {
      ShowCursor(true);
   }


   int GetDisplayWidth()
   {
      return GetSystemMetrics(SM_CXSCREEN);
   }

   int GetDisplayHeight()
   {
      return GetSystemMetrics(SM_CYSCREEN);
   }


   void GracefulShutdown()
   {
      PostQuitMessage(0);
   }

};
